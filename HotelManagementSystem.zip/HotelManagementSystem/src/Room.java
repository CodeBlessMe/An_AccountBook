//Create room
public class Room 
{
	private String wing;
	private int roomNumber;
	//'Ready' = 0, 'CheckedOut' = 1, 'Occupied' = 2
	private int status;
	private int people;
	private int clean;
	private int countRooms;
	
	public Room(String wing, int roomNumber, String status, int people, int clean, int countRooms)
	{
		this.status = judgeStatus(status);
		this.wing = wing;
		this.roomNumber = roomNumber;
		this.people = people;
		this.clean = clean;
		this.countRooms = countRooms;
	}
	
	public String getWing()
	{
		return wing;
	}
	
	public int getRoomNumber()
	{
		return roomNumber;
	}
	
	public String getStatus()
	{
		if (status == 0)
			return "READY";
		else if (status == 1)
			return "CHECKEDOUT";
		else
			return "OCCUPIED";
	}
	
	public int getPeople()
	{
		return people;
	}
	
	public int getClean()
	{
		return clean;
	}
	
	public int getCountRooms()
	{
		return countRooms;
	}
	
	public int judgeStatus(String status)
	{
		if (status == "READY")
			return 0;
		else if (status == "CHECKEDOUT")
			return 1;
		else
			return 2;
	}
	
	public void setStatus(String newStatus)
	{
		status = judgeStatus(newStatus);
	}
}