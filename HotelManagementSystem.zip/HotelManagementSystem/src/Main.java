//Test all project.
public class Main 
{
	public static void main(String[] args) 
	{
		HotelManagementSystem besthotel = new HotelManagementSystem();
		
		besthotel.addWing("Spring");
		besthotel.addWing("Summer");
		besthotel.addWing("Autumn");
		besthotel.addWing("Winter");
		besthotel.connectWings("Spring", "Summer", 25);
		besthotel.connectWings("Spring", "Winter", 80);
		besthotel.connectWings("Summer", "Winter", 100);
		besthotel.connectWings("Summer", "Autumn", 45);
		besthotel.connectWings("Autumn", "Winter", 130);
		
		besthotel.addDoubleRoom("Spring", 101, "READY");
		besthotel.addDoubleRoom("Summer", 102, "READY");
		besthotel.addFamilyRoom("Autumn", 103, "READY");
		besthotel.addFamilyRoom("Autumn", 104, "READY");
		besthotel.addDoubleRoom("Summer", 105, "READY");
		besthotel.addDoubleRoom("Summer", 106, "READY");
		besthotel.addDoubleRoom("Winter", 107, "READY");
		besthotel.addDoubleRoom("Winter", 108, "READY");
		int client1 = besthotel.addClient("Kenneth", "111@vub.be");
		int client2 = besthotel.addClient("Pinky", "222@vub.be");
		int client3 = besthotel.addClient("Mike", "2234@vub.be");
		int client4 = besthotel.addClient("Tony", "0013@vub.be");
		int client5 = besthotel.addClient("Vincent", "139@vub.be");
		besthotel.printClients();
		
		System.out.println(besthotel.checkInDoubleRoom(client1));
		System.out.println(besthotel.checkInFamilyRoom(client2));
		System.out.println(besthotel.checkInDoubleRoom(client3));
		System.out.println(besthotel.checkInDoubleRoom(client4));
		System.out.println(besthotel.checkInFamilyRoom(client5));
		System.out.println(besthotel.checkOutRoom(client1));
		System.out.println(besthotel.checkOutRoom(client5));
		System.out.println(besthotel.checkOutRoom(client2));
		
		besthotel.printRooms();
		//besthotel.printAvailableRooms();
		//besthotel.printOccupiedRooms();
		//besthotel.organizeCleaning();
		//besthotel.printRooms();
	}
}