public class Vector 
{
    protected Object[] data;
    protected int count;
    
    //Create a vector
    public Vector(int capacity)
    {
        data = new Object[capacity];
        count = 0;
    }
    
    //get value from position index
    public Object get(int index)
    {
    	return data[index];
    }
    
    //Add elements to the vector from last
    public void addLast(Object o)
    {
    	if (count == data.length)
    		extendCapacity();
        data[count] = o;
        count++;
    }
    
    //reset the value again
    public void set(int index, Object obj)
    {
    	data[index] = obj;
    }
    
    //return size of vector
    public int size()
    {
    	return count;
    }
    
    //Double the capacity of the vector
    private void extendCapacity()
    {
        Object[] data2 = new Object[data.length * 2];
        for (int i = 0; i < data.length; i++)
        {
            data2[i] = data[i];
        }
        data = data2;
    }
    
    public int find(Comparable wing)
    {
    	for (int i = 0; i < count; i++)
    	{
    		if ((String)data[i] == wing)
    			return 1;
    	}
    	return 0;
    }
    
    public int findWing(String name)
    {
    	for (int i = 0; i < count; i++)
    	{
    		Wing wing = (Wing) data[i];
    		if (wing.getName() == name)
    			return wing.getCountWing();
    	}
    	return -1;
    }
    
    public void delete(int i)
    {
    	Object[] newdata = new Object[count-1];
    	for (int j = 0; j < i;j++)
    	{
    		newdata[j] = data[j];
    	}
    	for (int k = i+1; k < count; k ++)
    	{
    		newdata[k-1] = data[k];
    	}
    	count--;
    	data = newdata;
    }
    
    public void deletwing(String wing)
    {
    	Object[] newdata = new Object[count-1];
    	int num = 0;
    	String wingtemp;
    	for (int j = 0; j < count;j++)
    	{
    		wingtemp = (String) data[j];
    		if (wingtemp == wing)
    		{
    			num = j;
    			break;
    		}	
    	}
    	for (int j = 0; j < num;j++)
    	{
    		newdata[j] = data[j];
    	}
    	for (int k = num+1; k < count; k ++)
    	{
    		newdata[k-1] = data[k];
    	}
    	count--;
    	data = newdata;
    }
}
