public class MatrixGraph 
{
	private Matrix data;
	private int countedges;
	private int countnodes;
	
	public MatrixGraph(int nrNodes)
	{
		data = new Matrix(nrNodes);
		countnodes = nrNodes;
	}
	
	public void addEdge(int from, int to, double distance)
	{
		data.set(from, to, distance);
		data.set(to, from, distance);
		countedges++;
	}
	
	public int getEdge(int from, int to)
	{
		return (int) data.get(from, to);
	}
	
	public String toString()
	{
		String s = countnodes + " Vertices, " + countedges + " Edges\n";
		for (int i = 0; i < countnodes; i++)
		{
			for (int j = 0; j < countnodes; j++)
			{
				s += data.get(i, j) + " ";
			}
			s += "\n";
		}
		return s;
	}
	
	public void printGraph()
	{
		System.out.print(toString());
	}
	
	public void expandMatrix()
	{
		int length = data.size()+1;
		Matrix newdata = new Matrix(length);
		for (int i = 0; i < length-1; i++)
		{
			for (int j = 0; j < length-1; j++)
				newdata.set(i, j, data.get(i, j));
		}
		data = newdata;
		countnodes = length;
	}
}
