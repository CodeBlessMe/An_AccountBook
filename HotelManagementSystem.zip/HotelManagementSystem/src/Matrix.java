public class Matrix 
{	
	private double[][] data;
	private int length;
	
	public Matrix(int nrNodes)
	{
		length = nrNodes;
		data = new double[length][length];
		for (int i = 0; i < length; i++)
		{
			for (int j = 0; j < length; j++)
				data[i][j] = 0;
		}
	}

	
	public void set(int row, int col, double weight)
	{
		data[row][col] = weight;
	}
	
	public double get(int row, int col)
	{
		return (double) data[row][col];
	}
	
	public void printall()
	{
		for (int i = 0; i < length; i++)
		{
			for (int j = 0; j < length; j++)
			{				
				System.out.print(data[i][j]);
				System.out.print(' ');
			}
			System.out.print("\n");
		}
	}
	
	public int size()
	{
		return length;
	}
}

