//Create client
public class Client 
{
	private String name;
	private String emailAddress;
	private int dclient;
	
	public Client(String name, String emailAddress, int countClients)
	{
		this.name = name;
		this.emailAddress = emailAddress;
		this.dclient = countClients;
	}
	
	public String getName()
	{
		return name;
	}
	
	public String getEmailAddress()
	{
		return emailAddress;
	}
	
	public int getCountClients()
	{
		return dclient;
	}
}
