
//I used the difference between number of clients of DoubleRoom and FamilyRoom to distinguish them.
//This class for any methods
//'Ready' = 0, 'CheckedOut' = 1, 'Occupied' = 2
public class HotelManagementSystem implements IManagementSystem
{
	private Vector rooms;
	private Vector clients;
	private Vector checkin = new Vector(5);
	private Vector avaiblerooms = new Vector(5);
	private Vector occupiedrooms = new Vector(5);
	private Vector checkedoutfamily = new Vector(5);
	private Vector checkedoutdouble = new Vector(5);
	private Vector wingfamily = new Vector(5);
	private Vector wingdouble = new Vector(5);
	private Vector wings;
	private MatrixGraph graph;
	private int countrooms = 0;
	private int countclients = 0;
	private int countwings = 0;
	
	//Create arrays to store data of rooms and clients
	public HotelManagementSystem()
	{
		rooms = new Vector(5);
		clients = new Vector(5);
		wings = new Vector(5);
	}

	//Add double rooms
	@Override
	public int addDoubleRoom(String wing, int roomNumber, String status) 
	{
		countrooms++;
		Room room = new Room(wing, roomNumber, status, 2, 1, countrooms);
		rooms.addLast(room);
		return countrooms;
	}

	//Add family rooms
	@Override
	public int addFamilyRoom(String wing, int roomNumber, String status) 
	{
		countrooms++;
		Room room = new Room(wing, roomNumber, status, 4, 2, countrooms);
		rooms.addLast(room);
		return countrooms;
	}
	
	//Add clients
	@Override
	public int addClient(String name, String emailAddress) 
	{
		countclients++;
		Client client = new Client(name, emailAddress, countclients);
		clients.addLast(client); 
		return countclients;
	}

	//Print the information of all rooms
	@Override
	public void printRooms() 
	{
		System.out.println("***********************************************");
		System.out.println("The BestHotel has following rooms:");
		System.out.println("Wing   | RoomNumber | Status      | ID");
		for (int i = 0; i < countrooms; i++)
		{   
			Room temp = (Room) rooms.get(i);			
			System.out.printf("%-7s| ", temp.getWing());
			System.out.printf("%-11s| ", temp.getRoomNumber());
			System.out.printf("%-12s| ", temp.getStatus());
			System.out.println(temp.getCountRooms());
		}
		System.out.println("***********************************************");
	}

	////Print the information of all clients
	@Override
	public void printClients() 
	{
		System.out.println("***********************************************");
		System.out.println("The BestHotel has following clients:");
		System.out.println("Name      | EmailAddress   | ID");
		for (int i = 0; i < countclients; i++)
		{
			Client temp = (Client) clients.get(i);
			System.out.printf("%-10s| ", temp.getName());
			System.out.printf("%-15s| ", temp.getCountClients());
			System.out.println(temp.getCountClients());
		}
		System.out.println("***********************************************");
	}

	//check in Double Room, and change this room's status to OCCUPIED
	@Override
	public int checkInDoubleRoom(int client) 
	{
		int n = 0;
		Room temp = (Room) rooms.get(n);
		while ((temp.getPeople() == 4) || (temp.getStatus() == "OCCUPIED"))
		{
			n++;
			temp = (Room) rooms.get(n);
			if (n > countrooms-1)
			{
				System.out.println("We don't have unoccupied room.");
				return 0;
			}		
		}
		if (temp.getStatus() == "READY")
		{
			temp.setStatus("OCCUPIED");
			int[] link = {client, n};
			checkin.addLast(link);
			return n+1;
		}
		else
		{
			System.out.println("You need to wait until the cleaning of this room has finished ");
			return n+1;
		}
	}

	//check in Family Room, and change this room's status to OCCUPIED
	@Override
	public int checkInFamilyRoom(int client) 
	{
		int n = 0;
		Room temp = (Room) rooms.get(n);
		while ((temp.getPeople() == 2) || (temp.getStatus() == "OCCUPIED"))
		{
			n++;
			temp = (Room) rooms.get(n);
			if (n > countrooms-1)
			{
				System.out.println("We don't have unoccupied room.");
				return 0;
			}
		}
		if (temp.getStatus() == "READY")
		{
			temp.setStatus("OCCUPIED");
			int[] link = {client, n};
			checkin.addLast(link);
			return n+1;
		}
		else
		{
			System.out.println("You need to wait until the cleaning of this room has finished ");
			return n+1;
		}
	}

	//check out client, change this room's state to CHECKEDOUT
	@Override
	public boolean checkOutRoom(int client) 
	{
		int n = 0;
		int[] temp = (int[]) checkin.get(n);
		while (temp[0] != client)
		{
			n++;
			temp = (int[]) checkin.get(n);
			if (n > checkin.size() - 1)
				return false;
		}
		Room willchange = (Room) rooms.get(temp[1]);
		willchange.setStatus("CHECKEDOUT");
		return true;
	}

	//this method use Vector avaiblerooms to store avaible rooms
	@Override
	public Vector searchAvailableRooms() 
	{
		int n = 0;
		Room temp = (Room) rooms.get(n);
		while (n < countrooms)
		{
			if (temp.getStatus() == "READY")
				avaiblerooms.addLast(n+1);
			n++;
			temp = (Room) rooms.get(n);
		}
		return avaiblerooms;
	}

	//print Vector avaiblerooms
	@Override
	public void printAvailableRooms() 
	{
		System.out.println("***********************************************");
		System.out.println("The BestHotel has available rooms:");
		System.out.println("Wing   | RoomNumber | Status      | ID");
		Vector avaiblerooms = searchAvailableRooms();
		int n1 = avaiblerooms.size();
		for (int i = 0; i < n1; i++)
		{   
			int num = (int) avaiblerooms.get(i);
			Room temp = (Room) rooms.data[num-1];		
			System.out.printf("%-7s| ", temp.getWing());
			System.out.printf("%-11s| ", temp.getRoomNumber());
			System.out.printf("%-12s| ", temp.getStatus());
			System.out.println(temp.getCountRooms());
		}
		System.out.println("***********************************************");
	}

	//this method use Vector occupiedrooms to store occupied rooms, then print this Vector
	@Override
	public void printOccupiedRooms() 
	{
		int n = 0;
		Room temp = (Room) rooms.get(n);
		while (n < countrooms)
		{
			if (temp.getStatus() == "OCCUPIED")
				occupiedrooms.addLast(n+1);
			n++;
			temp = (Room) rooms.get(n);
		}
		System.out.println("***********************************************");
		System.out.println("The BestHotel has occupied rooms:");
		System.out.println("Wing   | RoomNumber | Status      | ID");
		int n2 = occupiedrooms.size();
		for (int i = 0; i < n2; i++)
		{   
			int num = (int) occupiedrooms.get(i);
			temp = (Room) rooms.data[num-1];		
			System.out.printf("%-7s| ", temp.getWing());
			System.out.printf("%-11s| ", temp.getRoomNumber());
			System.out.printf("%-12s| ", temp.getStatus());
			System.out.println(temp.getCountRooms());
		}
		System.out.println("***********************************************");
	}

	
	@Override
	public void addWing(String wingName) 
	{
		Wing wing = new Wing(wingName,countwings);
		if (countwings == 0)
		{
			countwings++;
		}
		else if (countwings == 1)
		{
			graph = new MatrixGraph(2);
			countwings++;
		}
		else
		{
			graph.expandMatrix();
			countwings++;
		}
		wings.addLast(wing);
	}

	//my wing plan is same as the example in Canvas
	@Override
	public void connectWings(String wing1, String wing2, double distance) 
	{
		int num1 = wings.findWing(wing1);
		int num2 = wings.findWing(wing2);
		graph.addEdge(num1, num2, distance);
	}

	
	@Override
	public void organizeCleaning() 
	{
		
	}
}
